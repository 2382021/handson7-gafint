export class CreateSongDTO{
    title: string;
    artist: string;
}