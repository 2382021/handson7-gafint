export class Songs{
    id: number;
    title: string;
    artist: string;
}